#!/usr/bin/env bash
python -m g4f --port 8080 --debug --reload